/******************************************************
*Name: Rick Clapham
*Date: Oct 20/2015
*StudentID: 821-490-125
*Program: CENG 318
*Instructor: Syed Tanber
*
* Program: Set-C
******************************************************/

import java.util.*;
import java.util.ArrayList;
import java.util.Set;

public class Richard_821490125
{ 
   public Richard_821490125(){}

   
   public void compareTo(int[] myArray)
   {
   }
   
   public static void main (String [] args)
   {
      Richard_821490125 myClass = new Richard_821490125();
      int[] myArray = {7,2,8,9,4,2,5,6,7,7,8,0,12,5,3,6};
      List<Integer> myArrayList = new ArrayList<>();
      Set<Integer> mySet = new HashSet<>();
      
      System.out.println("------------------------------");
      
      for(int count1=0; count1 < myArray.length; count1++)
      {
         for(int count2=0; count2 < myArray.length; count2++)
         {
            if(count1 != count2)
            {
               if(myArray[count1] == myArray[count2])
               {
                  myArrayList.add(myArray[count1]); 
               }
            }
         }
      }
      
      mySet.addAll(myArrayList);
      myArrayList.clear();
      myArrayList.addAll(mySet);
      
      System.out.println("\n" + myArrayList + "\n");
      
      int sum = myArrayList.get(0) + myArrayList.get(1);
      System.out.println("The smallest Sum is: " + sum);
      
      System.out.println("\nAlternative Elements");

      for(int count = 0; count < myArrayList.size(); count = count + 2)  
      {
         System.out.print(myArrayList.get(count) + ", ");
      } 
      
   }
}


