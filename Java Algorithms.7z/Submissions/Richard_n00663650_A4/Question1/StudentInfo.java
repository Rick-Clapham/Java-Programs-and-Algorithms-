/******************************************************
*Name: Rick Clapham
*Date: Nov 9, 2015
*StudentID: 821-490-125
*Program: CENG318
*Instructor: Syed Tanber    
******************************************************/

import java.util.*;

public class StudentInfo implements Comparable
{ 

   private String mostContributedCity = "";
   
   public int compareTo (Object newStudent)
   {
      if(mostContributedCity.compareToIgnoreCase(((Student)newStudent).getHomeCity()) == 1)
         return 1;
      else 
         return 0;
   }
   
   public void printList (LinkedList<Student> newList)
   {
      ListIterator myIterator = newList.listIterator();
      System.out.println ("List of students: ");
      System.out.println ("----------------------------");
      while(myIterator.hasNext()){
         System.out.println(myIterator.next() + " ");
      }
   }
   
   public void findGPA (LinkedList<Student> newList)
   {
      double myNum = 0;
      String tempFirstName ="";
      int tempID = 0;
      String tempHomeCity = "";
      double tempGPA = 0;
      
      for (int x = 0; x < newList.size(); x++)
      {
            if (myNum < newList.get(x).getGPA())
            {
               myNum = newList.get(x).getGPA();
               tempFirstName = newList.get(x).getFirstName();
               tempID = newList.get(x).getID();
               tempHomeCity = newList.get(x).getHomeCity(); 
               tempGPA = newList.get(x).getGPA();
            }
      }
      System.out.println ("The Student with the highest GPA is: ");
      Student myStudent = new Student(tempFirstName,tempID,tempGPA,tempHomeCity);
      System.out.println (myStudent.toString());
   }
   
   public void findID (LinkedList<Student> newList)
   {
      double myNum = 999999999;
      String tempFirstName ="";
      int tempID = 0;
      String tempHomeCity = "";
      double tempGPA = 0;
      
      for (int x = 0; x < newList.size(); x++)
      {
            if (myNum > newList.get(x).getID())
            {
               tempFirstName = newList.get(x).getFirstName();
               tempID = newList.get(x).getID();
               tempHomeCity = newList.get(x).getHomeCity(); 
               tempGPA = newList.get(x).getGPA();
               myNum = newList.get(x).getID();
            }
      }
      System.out.println ("The Student with the Minimum ID is: ");
      Student myStudent = new Student(tempFirstName,tempID,tempGPA,tempHomeCity);
      System.out.println (myStudent.toString());
   }
   
   public void sameHomeCity (LinkedList<Student> newList)
   {
      int myBest = 0;
      mostContributedCity = newList.get(0).getHomeCity();
      for(int x = 0; x < newList.size(); x++)
      {
         int myCount = 0;
         for(int y = x + 1; y < newList.size(); y++)
         {
            if (compareTo(newList.get(y)) == 1)
               myCount++;
         }
         if(myBest < myCount)
         {
            myBest = myCount;
            mostContributedCity = newList.get(x).getHomeCity();
         }       
      }
      System.out.println("The most contributed City is: " + mostContributedCity);
      
      GenericStack<Student> myStack = new GenericStack<Student>();
      for(int x = 0; x < newList.size(); x++){
         if(newList.get(x).getHomeCity().equalsIgnoreCase(mostContributedCity))
            myStack.push(newList.get(x));
      }
      
      while(!myStack.isEmpty()){
         System.out.println(myStack.pop().toString());
      }
   }
   
   public static void main (String[] args)
   {
      StudentInfo newStudents = new StudentInfo ();
      LinkedList<Student> studentList = new LinkedList<Student>();
      
      studentList.add (new Student ("Rick",  821, 3.1, "Toronto"));
      studentList.add (new Student ("Derek", 490, 3.1, "Toronto"));
      studentList.add (new Student ("John", 125, 3.5, "Toronto"));
      studentList.add (new Student ("Saroch", 250, 3.9, "Detroit"));
      studentList.add (new Student ("Giselle", 2, 2.8, "Canada"));
      studentList.add (new Student ("Mami", 8100, 2.1, "Phoenix"));
      studentList.add (new Student ("Chris", 250, 2.5, "Phoenix"));
      
      newStudents.printList (studentList);
      System.out.println("\n---------------------");
      newStudents.findGPA (studentList);
      System.out.println("\n---------------------");
      newStudents.findID (studentList);
      System.out.println("\n---------------------");
      newStudents.sameHomeCity(studentList);
   }
}