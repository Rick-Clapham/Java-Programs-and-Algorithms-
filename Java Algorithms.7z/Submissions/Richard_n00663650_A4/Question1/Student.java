/******************************************************
*Name: Rick Clapham
*Date: Nov 9, 2015
*StudentID: 821-490-125
*Program: CENG318
*Instructor: Syed Tanber    
******************************************************/

public class Student
{
   private int id;
   private String firstName;
   private String homeCity;
   private double GPA;
   
   public Student()
   {
      id = 0;
      firstName = "Default";
      homeCity = "Default";
      GPA = 0;
   }
   
   public Student(String i1, int i2, double i3, String i4)
   {
      firstName = i1;
      id = i2;
      GPA = i3;
      homeCity = i4;
   }
   
   public void setID(int i){id = i;}
   public void setFirstName(String i){firstName = i;}
   public void setHomeCity(String i){homeCity = i;}
   public void setGPA(double i){GPA = i;}
   
   public int getID(){return id;}
   public String getFirstName(){return firstName;}
   public String getHomeCity(){return homeCity;}
   public double getGPA(){return GPA;}
   
   public String toString ()
   {
      return "Name:\t" + firstName + "\tGPA:\t" + GPA + "\tID Number:\t" + id + "\tCity:\t" + homeCity;
   }
}

