/******************************************************
*Name: Rick Clapham
*Date: Nov 9, 2015
*StudentID: 821-490-125
*Program: CENG318
*Instructor: Syed Tanber    
******************************************************/

public class GenericStack<E> {
  private java.util.ArrayList<E> list = new java.util.ArrayList<E>();
  
  public int getSize() {
    // return the size of the list
    return list.size();
  }

  public E peek() {
    //return the last elemetn in the list 
    return list.get(list.size()-1);
  }

  public void push(E o) {
   // add o into the list
   list.add(o);
  }

  public E pop() {
    // get the last element in the list and remove it from the list
     // return the last element
     E value = list.get(list.size()-1);
     list.remove(list.size()-1);
     return value;
      
  }

  public boolean isEmpty() {
    // check if the list is empty
    if(list.size()==0)
      return true;
      else
      return false;
  }
  
  @Override
  public String toString() {
	// return the list.toString()
   return list.toString();
  }


   public static void main(String[] args){}

}