/******************************************************
*Name: Rick Clapham
*Date: Nov 8, 2015
*StudentID: 821-490-125
*Program: CENG318
*Instructor: Syed Tanber
*Program: InitialBSTShow.java

* All of this program was taken form the textbook
******************************************************/
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class InitialBSTShow extends JApplet {
  public InitialBSTShow() {
    add(new BinaryTreeView(new BinaryTree<Integer>()));
  }

  public static void main(String[] args) {
    JFrame frame = new JFrame("BST Traversal");
    JApplet applet = new InitialBSTShow();
    frame.add(applet);
    frame.setSize(600, 300);
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    frame.setLocationRelativeTo(null);
    frame.setVisible(true);
  }

  class BinaryTreeView extends JPanel {
    private BinaryTree<Integer> tree; // A binary tree to be displayed
    private JTextField jtfKey = new JTextField(5);
    private PaintTree paintTree = new PaintTree();
    private JButton jbtInsert = new JButton("Insert");
    private JButton jbtDelete = new JButton("Delete");

    /** Construct a view for a binary tree */
    public BinaryTreeView(BinaryTree<Integer> tree) {
      this.tree = tree; // Set a binary tree to be displayed
      setInterface();
    }

    /** Initialize UI for binary tree */
    private void setInterface() {
      this.setLayout(new BorderLayout());
      add(paintTree, BorderLayout.CENTER);
      JPanel panel = new JPanel();
      panel.add(new JLabel("Enter a key: "));
      panel.add(jtfKey);
      panel.add(jbtInsert);
      panel.add(jbtDelete);
    
      add(panel, BorderLayout.SOUTH);

      // Listener for the Insert button
      jbtInsert.addActionListener(new ActionListener() {
        @Override 
        public void actionPerformed(ActionEvent e) {
          int key = Integer.parseInt(jtfKey.getText());
          if (tree.search(key)) { // key is in the tree already
            JOptionPane
                .showMessageDialog(null, key + " is already in the tree");
          } else {
            tree.insert(key); // Insert a new key
            paintTree.repaint(); // Redisplay the tree
          }
        }
      });

      // Listener for the Delete button
      jbtDelete.addActionListener(new ActionListener() {
        @Override 
        public void actionPerformed(ActionEvent e) {
          int key = Integer.parseInt(jtfKey.getText());
          if (!tree.search(key)) { // key is not in the tree
            JOptionPane.showMessageDialog(null, key + " is not in the tree");
          } else {
            tree.delete(key); // Delete a key
            paintTree.repaint(); // Redisplay the tree
          }
        }
      });
    }

    // Inner class PaintTree for displaying a tree on a panel
    class PaintTree extends JPanel {
      private int radius = 20; // Tree node radius

      private int vGap = 50; // Gap between two levels in a tree

      @Override
      protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        if (tree.getRoot() != null) {
          // Display tree recursively
          displayTree(g, tree.getRoot(), getWidth() / 2, 30, getWidth() / 4);
        }
      }

      /** Display a subtree rooted at position (x, y) */
      private void displayTree(Graphics g, BinaryTree.TreeNode root, int x,
          int y, int hGap) {
        // Display the root
        g.drawOval(x - radius, y - radius, 2 * radius, 2 * radius);
        g.drawString(root.element + "", x - 6, y + 4);

        if (root.left != null) {
          // Draw a line to the left node
          connectLeftChild(g, x - hGap, y + vGap, x, y);
          // Draw the left subtree recursively
          displayTree(g, root.left, x - hGap, y + vGap, hGap / 2);
        }

        if (root.right != null) {
          // Draw a line to the right node
          connectRightChild(g, x + hGap, y + vGap, x, y);
          // Draw the right subtree recursively
          displayTree(g, root.right, x + hGap, y + vGap, hGap / 2);
        }
      }

      /**
       * Connect a parent at (x2, y2) with its left child at (x1, y1)
       */
      private void connectLeftChild(Graphics g, int x1, int y1, int x2, int y2) {
        double d = Math.sqrt(vGap * vGap + (x2 - x1) * (x2 - x1));
        int x11 = (int) (x1 + radius * (x2 - x1) / d);
        int y11 = (int) (y1 - radius * vGap / d);
        int x21 = (int) (x2 - radius * (x2 - x1) / d);
        int y21 = (int) (y2 + radius * vGap / d);
        g.drawLine(x11, y11, x21, y21);
      }

      /**
       * Connect a parent at (x2, y2) with its right child at (x1, y1)
       */
      private void connectRightChild(Graphics g, int x1, int y1, int x2, int y2) {
        double d = Math.sqrt(vGap * vGap + (x2 - x1) * (x2 - x1));
        int x11 = (int) (x1 - radius * (x1 - x2) / d);
        int y11 = (int) (y1 - radius * vGap / d);
        int x21 = (int) (x2 + radius * (x1 - x2) / d);
        int y21 = (int) (y2 + radius * vGap / d);
        g.drawLine(x11, y11, x21, y21);
      }
    }
  }

  class BinaryTree<E extends Comparable<E>> extends AbstractTree<E> {
    protected TreeNode<E> root;

    protected int size = 0;

    /** Create a default binary tree */
    public BinaryTree() {
    }

    /** Create a binary tree from an array of objects */
    public BinaryTree(E[] objects) {
      for (int i = 0; i < objects.length; i++)
        insert(objects[i]);
    }

    /** Returns true if the element is in the tree */
    public boolean search(E e) {
      TreeNode<E> current = root; // Start from the root

      while (current != null) {
        if (e.compareTo(current.element) < 0) {
          current = current.left;
        } else if (e.compareTo(current.element) > 0) {
          current = current.right;
        } else
          // element matches current.element
          return true; // Element is found
      }

      return false;
    }

    /**
     * Insert element o into the binary tree Return true if the element is
     * inserted successfully
     */
    public boolean insert(E e) {
      if (root == null)
        root = createNewNode(e); // Create a new root
      else {
        // Locate the parent node
        TreeNode<E> parent = null;
        TreeNode<E> current = root;
        while (current != null)
          if (e.compareTo(current.element) < 0) {
            parent = current;
            current = current.left;
          } else if (e.compareTo(current.element) > 0) {
            parent = current;
            current = current.right;
          } else
            return false; // Duplicate node not inserted

        // Create the new node and attach it to the parent node
        if (e.compareTo(parent.element) < 0)
          parent.left = createNewNode(e);
        else
          parent.right = createNewNode(e);
      }

      size++;
      return true; // Element inserted
    }

    protected TreeNode<E> createNewNode(E e) {
      return new TreeNode<E>(e);
    }

    /** Inner class tree node */
    public class TreeNode<E extends Comparable<E>> {
      E element;
      TreeNode<E> left;
      TreeNode<E> right;

      public TreeNode(E e) {
        element = e;
      }
    }

    /** Get the number of nodes in the tree */
    public int getSize() {
      return size;
    }

    /** Returns the root of the tree */
    public TreeNode getRoot() {
      return root;
    }

    /** Returns a path from the root leading to the specified element */
    public java.util.ArrayList<TreeNode<E>> path(E e) {
      java.util.ArrayList<TreeNode<E>> list = new java.util.ArrayList<TreeNode<E>>();
      TreeNode<E> current = root; // Start from the root

      while (current != null) {
        list.add(current); // Add the node to the list
        if (e.compareTo(current.element) < 0) {
          current = current.left;
        } else if (e.compareTo(current.element) > 0) {
          current = current.right;
        } else
          break;
      }

      return list; // Return an array of nodes
    }

    /**
     * Delete an element from the binary tree. Return true if the element is
     * deleted successfully Return false if the element is not in the tree
     */
    public boolean delete(E e) {
      // Locate the node to be deleted and also locate its parent node
      TreeNode<E> parent = null;
      TreeNode<E> current = root;
      while (current != null) {
        if (e.compareTo(current.element) < 0) {
          parent = current;
          current = current.left;
        } else if (e.compareTo(current.element) > 0) {
          parent = current;
          current = current.right;
        } else
          break; // Element is in the tree pointed by current
      }

      if (current == null)
        return false; // Element is not in the tree

      // Case 1: current has no left children
      if (current.left == null) {
        // Connect the parent with the right child of the current node
        if (parent == null) {
          root = current.right;
        } else {
          if (e.compareTo(parent.element) < 0)
            parent.left = current.right;
          else
            parent.right = current.right;
        }
      } else {
        // Case 2: The current node has a left child
        // Locate the rightmost node in the left subtree of
        // the current node and also its parent
        TreeNode<E> parentOfRightMost = current;
        TreeNode<E> rightMost = current.left;

        while (rightMost.right != null) {
          parentOfRightMost = rightMost;
          rightMost = rightMost.right; // Keep going to the right
        }

        // Replace the element in current by the element in rightMost
        current.element = rightMost.element;

        // Eliminate rightmost node
        if (parentOfRightMost.right == rightMost)
          parentOfRightMost.right = rightMost.left;
        else
          // Special case: parentOfRightMost == current
          parentOfRightMost.left = rightMost.left;
      }

      size--;
      return true; // Element inserted
    }
}

  interface Tree<E extends Comparable<E>> {
    /** Return true if the element is in the tree */
    public boolean search(E e);

    /**
     * Insert element o into the binary tree Return true if the element is
     * inserted successfully
     */
    public boolean insert(E e);

    /**
     * Delete the specified element from the tree Return true if the element is
     * deleted successfully
     */
    public boolean delete(E e);

    /** Get the number of nodes in the tree */
    public int getSize();

    /** Return true if the tree is empty */
    public boolean isEmpty();

    /** Return an iterator to traverse elements in the tree */
    public java.util.Iterator iterator();
  }

  abstract class AbstractTree<E extends Comparable<E>> implements Tree<E> {
    /** Return true if the tree is empty */
    public boolean isEmpty() {
      return getSize() == 0;
    }

    /** Return an iterator to traverse elements in the tree */
    public java.util.Iterator iterator() {
      return null;
    }
  }
}