/*
* Name: Rick Clapham
* Student #: 821-490-125
* Student ID: n00663650
* Last Modified: 10/14/2015

* Assignment No.: 3
* Submission date: 10/27/2015
* Instructor�s name: Syed Tanbeer
*/

import java.util.ArrayList;
import java.io.*;

public class cardGame_Richard_821490125
{
   ArrayList<card_Richard_821490125> myDeck = new ArrayList<card_Richard_821490125>();
   ArrayList<card_Richard_821490125> player1 = new ArrayList<card_Richard_821490125>();
   ArrayList<card_Richard_821490125> player2 = new ArrayList<card_Richard_821490125>();
   ArrayList<card_Richard_821490125> player3 = new ArrayList<card_Richard_821490125>();
   ArrayList<card_Richard_821490125> player4 = new ArrayList<card_Richard_821490125>();
   private int p1Score = 0; 
   private int p2Score = 0;
   private int p3Score = 0;
   private int p4Score = 0;
   final static int deckSize = 52;
   
   public cardGame_Richard_821490125(){}
   
   /*
   * Setups the initial deck with 52 cards
   * @param ArrayList<card_Richard_821490125> i recieves the arrayList to loadthe cars into
   */
   
   public static void setupDeck (ArrayList<card_Richard_821490125> i)
   {
      for(int count1 = 1; count1 <= 4; count1++)
      {
         for(int count2 = 1; count2 <= 13; count2++)
         {
            card_Richard_821490125 myCard = new card_Richard_821490125();
            myCard.setSuite(count1);
            myCard.setRank(count2);
            i.add(myCard);
         }
      }
   }
   
   /*
   * Shuffles the deck
   * @param ArrayList<card_Richard_821490125> i recieves array list of cards
   */
   
   public static void shuffleDeck (ArrayList<card_Richard_821490125> i)
   {
      for(int count = 0; count < i.size(); count++)
      {
         int index = (int)(Math.random() * i.size());
         card_Richard_821490125 temp = i.get(count);
         i.set(count, i.get(index));
         i.set(index, temp);
      }
   }
   
   /*
   * Divides the main deck of cards into multiple decks
   * @param ArrayList<card_Richard_821490125> i recieves array list of cards and divides them to the players
   */
   
   public void distributeDeck (ArrayList<card_Richard_821490125> i)
   {
      for(int count1 = 1; count1 <= 13; count1++)
      {
         for(int count2 = 1; count2 <= 4; count2++)
         {
            if(count2 == 1){player1.add(myDeck.get(0)); myDeck.remove(0);}
            if(count2 == 2){player2.add(myDeck.get(0)); myDeck.remove(0);}
            if(count2 == 3){player3.add(myDeck.get(0)); myDeck.remove(0);}
            if(count2 == 4){player4.add(myDeck.get(0)); myDeck.remove(0);}
         }
      }
   }
   
   /*
   * Displays the rounds of cards in a neat display and calls roundWinner to determine the winner
   * @param ArrayList<card_Richard_821490125> P1 player 1's deck
   * @param ArrayList<card_Richard_821490125> P2 player 2's deck
   * @param ArrayList<card_Richard_821490125> P3 player 3's deck
   * @param ArrayList<card_Richard_821490125> P4 player 4's deck
   */
   
   public void playCards (ArrayList<card_Richard_821490125> p1, ArrayList<card_Richard_821490125> p2, ArrayList<card_Richard_821490125> p3, ArrayList<card_Richard_821490125> p4)
   {
      System.out.println("\nStatus of all deals\tP-1\tP-2\tP-3\tP-4");
      int dealCount = 0;
      for(int count = 0; count < p1.size(); count++)
      {
         dealCount= count+1;
         System.out.print("Deal Number " + dealCount + ":\t\t");
         System.out.print(p1.get(count).getSuite() + " ");
         System.out.print(p1.get(count).getRank() + "\t");
         System.out.print(p2.get(count).getSuite() + " ");
         System.out.print(p2.get(count).getRank() + "\t");
         System.out.print(p3.get(count).getSuite() + " ");
         System.out.print(p3.get(count).getRank() + "\t");
         System.out.print(p4.get(count).getSuite() + " ");
         System.out.println(p4.get(count).getRank());
         roundWinner(count, p1, p2, p3, p4);
      }
   }
   
   /*
   * Determines the current round winner method is called from within playcards
   * @param int count current round count
   * @param ArrayList<card_Richard_821490125> P1 player 1's deck
   * @param ArrayList<card_Richard_821490125> P2 player 2's deck
   * @param ArrayList<card_Richard_821490125> P3 player 3's deck
   * @param ArrayList<card_Richard_821490125> P4 player 4's deck
   */
   
   public void roundWinner(int count, ArrayList<card_Richard_821490125> p1, ArrayList<card_Richard_821490125> p2, ArrayList<card_Richard_821490125> p3, ArrayList<card_Richard_821490125> p4)
   {
      int currentLargestR = p1.get(count).getRank();
      int currentLargestS = p1.get(count).getSuite();
      
      if(currentLargestR < p2.get(count).getRank())
      {
         currentLargestR = p2.get(count).getRank();
         currentLargestS = p2.get(count).getSuite();
      }
      if(currentLargestR == p2.get(count).getRank())
      {
         if(currentLargestS < p2.get(count).getSuite())
         currentLargestR = p2.get(count).getRank();
         currentLargestS = p2.get(count).getSuite();
      }
      
      if(currentLargestR < p3.get(count).getRank())
      {
         currentLargestR = p3.get(count).getRank();
         currentLargestS = p3.get(count).getSuite();
      }
      if(currentLargestR == p3.get(count).getRank())
      {
         if(currentLargestS < p3.get(count).getSuite())
         currentLargestR = p3.get(count).getRank();
         currentLargestS = p3.get(count).getSuite();
      }
      
      if(currentLargestR < p4.get(count).getRank())
      {
         currentLargestR = p4.get(count).getRank();
         currentLargestS = p4.get(count).getSuite();
      }
      if(currentLargestR == p4.get(count).getRank())
      {
         if(currentLargestS < p4.get(count).getSuite())
         currentLargestR = p4.get(count).getRank();
         currentLargestS = p4.get(count).getSuite();
      }
      
      if(currentLargestR == p1.get(count).getRank() && currentLargestS == p1.get(count).getSuite())
         p1Score++;
      if(currentLargestR == p2.get(count).getRank() && currentLargestS == p2.get(count).getSuite())
         p2Score++;
      if(currentLargestR == p3.get(count).getRank() && currentLargestS == p3.get(count).getSuite())
         p3Score++;
      if(currentLargestR == p4.get(count).getRank() && currentLargestS == p4.get(count).getSuite())
         p4Score++;    
   }
   
   /*
   * Displays the winner(s) of the card game
   */
   
   public void displayWinner()
   {
      int winner;
      
      if ((p1Score >= p2Score) && (p1Score >= p3Score) && (p1Score >= p4Score)) { // a >= b,c,d,e
      winner = p1Score;
      }else if((p2Score >= p3Score) && (p2Score >= p4Score)){
      winner = p2Score;
      }else if((p3Score >= p4Score)){
      winner = p3Score;
      }else{
      winner = p4Score;}
      
      System.out.println();
      if(winner == p1Score){System.out.println("Overall winner(s) is Player-1");}
      if(winner == p2Score){System.out.println("Overall winner(s) is Player-2");}
      if(winner == p3Score){System.out.println("Overall winner(s) is Player-3");}
      if(winner == p4Score){System.out.println("Overall winner(s) is Player-4");}
   }
   
   /*
   * Displays the players final score
   */
   
   public void displayScore()
   {
      System.out.println("\nDeal Winners:");
      System.out.println("Players:\tNo. of Deal(s) Won");
      System.out.println("1:\t" + p1Score);
      System.out.println("2:\t" + p2Score);
      System.out.println("3:\t" + p3Score);
      System.out.println("4:\t" + p4Score);
   }
   
   /*
   * Displays the contents within the main deck used for testing only
   * @param: ArrayList<card_Richard_821490125
   */
   
   public static void displayDeck (ArrayList<card_Richard_821490125> i)
   {
      for(int count = 0; count < i.size(); count ++)
      {
         System.out.print(i.get(count).getSuite() + " ");
         System.out.println(i.get(count).getRank());
      }
   }
   
   /*
   * Main Method
   */

   public static void main(String [] args)
   {
      cardGame_Richard_821490125 myCardGame = new cardGame_Richard_821490125();
      
      System.out.println("Card Game Simulation by Richard_821490125");
      myCardGame.setupDeck(myCardGame.myDeck);
      myCardGame.shuffleDeck(myCardGame.myDeck);
      myCardGame.distributeDeck(myCardGame.myDeck);
      
      System.out.println("\nDistribution of Cards:");
      System.out.println("\nCards for Player 1");
      myCardGame.displayDeck(myCardGame.player1);
      System.out.println("\nCards for Player 2");
      myCardGame.displayDeck(myCardGame.player2);
      System.out.println("\nCards for Player 3");
      myCardGame.displayDeck(myCardGame.player3);
      System.out.println("\nCards for Player 4");
      myCardGame.displayDeck(myCardGame.player4);
      
      myCardGame.playCards(myCardGame.player1, myCardGame.player2, myCardGame.player3, myCardGame.player4);   
      myCardGame.displayScore();   
      myCardGame.displayWinner();
      
   }
}
