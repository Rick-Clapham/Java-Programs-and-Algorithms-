/*****************************************************************************
*Name: Rick Clapham
*Date: Sep 16/2015
*Student # n00663650
*Program: CENG318
*Instructor: Syed Tanber
*
* A program that recieves 2 strings from the user and will then
* compare the 2 strings and return the identical characters to the user
******************************************************************************/

import java.util.*;

public class matchLetters
{
   public matchLetters()
   {
   }
  
/****************************************************************************
Public static String readString recieves a String from the user and return
the string.
****************************************************************************/

   public static String readString()
	{
		Scanner in = new Scanner(System.in);	
		String myString = in.next();
		return myString;
	}
   
/****************************************************************************
Public char[] comepareTo
@parem Recieves two strings from the user will return a char if they are both identical
This function is case sensitive and will not reutrn a value if e & E are both entered.
This can easily be impletemtented toLowerCase(); see bewlow lines. (currently commented out.)
You can also use toUpperCase();
****************************************************************************/
   
   public char[] compareTo(String myString1, String myString2)
   {
      //myString1 = myString1.toLowerCase();
      //myString2 = myString2.toLowerCase();
      
      int arraySize = 100;
      int count3=0;
      
      if(myString1.length() >= myString2.length())
      {
         arraySize = myString1.length();
      }
      else
      {
         arraySize = myString2.length();
      }
      char myArray[] = new char[arraySize];
      
      for(int count1=0; count1 < myString1.length(); count1++)
      {
         for(int count2=0; count2 < myString2.length(); count2++)
         {
            if(myString2.charAt(count2) == myString1.charAt(count1))
            {
              myArray[count3] = myString1.charAt(count1); 
              count3++;   
            }
         }
      }
      return myArray;
   }
   
   public static void main(String[] args)
   {
      matchLetters myMatchLetters = new matchLetters();
      System.out.println("------------------------------");
      System.out.print("Insert String 1:\t"); 
      String myString1 = myMatchLetters.readString();
      System.out.print("Insert String 2:\t");  
      String myString2 = myMatchLetters.readString();
      System.out.println("------------------------------");
      System.out.println(myString1);
      System.out.println(myString2);
      System.out.println("------------------------------");
      
      System.out.println(myMatchLetters.compareTo(myString1, myString2));

   }
}