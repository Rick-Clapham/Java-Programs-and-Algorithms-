/******************************************************
*Name: Richard Clapham
*Student#: 821-490-125
*Student ID: n00663650
*Last Modified: 10/05/2015
*
* Recieves an interger value from the user that will determine the 
* Size of the array it will then generate random numbers from 
* 1-10 and then using an insertion sort method will sort them
******************************************************/

import java.util.*;
import java.util.ArrayList;

public class SelSort
{
   /*
   * Recieves interger from user Makes sure the value is positive and an interger
   */
   public static int readInt()
	{
		int i = 0;		//Initialize for return
		boolean failure = false;
		Scanner in = new Scanner(System.in);
		do
		{
			failure = false;	//Reinitialize for if
			if (in.hasNextInt())
         {
				i = in.nextInt(); //Good one
            if(i < 0)
            {
               failure = true;
				   System.out.print("Please enter a positive integer: ");
            }
         } 
			else
			{
				failure = true;
				String temp = in.next();	//Clear the buffer
				System.out.print("Please enter an integer: ");
			}
		}while(failure); 	
		return i;
	}
   
   /**
   *A function when given 2 valus will determine the larger value and then
   *determine a math.random function for the 2 values and return the num
   * 
   */
   public static int generateNum(int x, int y)
   {
      if(x > y)
      {
         return (int)(Math.random()*(x-y+1)+ y);
      }
      else
      {
         return (int)(Math.random()*(y-x+1)+ x);
      }
   }
   
   /**
   Simple method to print an interger array in order to make code look neater
   */
   public static void printArray(int[] myArray)
   {
      for(int count = 0; count < myArray.length; count++)
      {
         System.out.print(myArray[count]+ ", ");
      }
      System.out.println("\n");
   }
   
   /**
   * Insertion Sort method taken from textbook: 
   * Introduction to java programming ninth edition
   */
   public static int[] InsertionSort(int[] list)
   {
      for(int i = 1; i <list.length; i++)
      {
         int currentElement = list[i];
         int k;
         for(k = i -1; k >= 0 && list[k] > currentElement; k--)
         {
            list[k+1] = list[k];
         }
         list[k + 1] = currentElement;
      }
      return list;
   }
   
   public static void main(String[] args) 
   {
      SelSort myMain = new SelSort();
      System.out.println("Enter the Array Size(n):\t");
      int n = readInt(); 
      int[] myArray = new int[n];
      
       //Fills array with random nums from 1-10
      for(int count = 0; count < n; count++)
      {
         myArray[count] = generateNum(1,10);
      } 
       
      //prints out sorted Array
      System.out.println("\nMy Unsorted Array: ");
      printArray(myArray);

      int[] mySortedArray = new int[myArray.length];
      mySortedArray = InsertionSort(myArray);
      
      //prints out sorted Array
      System.out.println("My sorted Array: ");
      printArray(mySortedArray);
   }
}