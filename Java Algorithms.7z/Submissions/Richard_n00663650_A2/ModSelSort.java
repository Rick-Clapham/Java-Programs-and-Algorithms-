/******************************************************
*Name: Richard Clapham
*Student#: 821-490-125
*Student ID: n00663650
*Last Modified: 10/05/2015
*
* Recieves an interger value from the user that will determine the 
* Size of the array it will then generate random numbers from 
* 1-10 and then using and a modified insertion sort method will sort them
******************************************************/

import java.util.*;
import java.util.ArrayList;

public class ModSelSort
{
   /*
   * Recieves interger from user Makes sure the value is positive and an interger
   */
   public static int readInt()
	{
		int i = 0;		//Initialize for return
		boolean failure = false;
		Scanner in = new Scanner(System.in);
		do
		{
			failure = false;	//Reinitialize for if
			if (in.hasNextInt())
         {
				i = in.nextInt(); //Good one
            if(i < 0)
            {
               failure = true;
				   String temp = in.next();	//Clear the buffer
				   System.out.print("Please enter a positive integer: ");
            }
         } 
			else
			{
				failure = true;
				String temp = in.next();	//Clear the buffer
				System.out.print("Please enter an integer: ");
			}
		}while(failure); 	
		return i;
	}
   
   /**
   *A function when given 2 valus will determine the larger value and then
   *determine a math.random function for the 2 values and return the num
   * 
   */
   public static int generateNum(int x, int y)
   {
      if(x > y)
      {
         return (int)(Math.random()*(x-y+1)+ y);
      }
      else
      {
         return (int)(Math.random()*(y-x+1)+ x);
      }
   }
   
   /**
   Simple method to print an interger array in order to make code look neater
   */
   public static void printArray(int[] myArray)
   {
      for(int count = 0; count < myArray.length; count++)
      {
         System.out.print(myArray[count]+ ", ");
      }
      System.out.println("\n");
   }
   
   public static int[] InsertionSort(int[] list)
   {
      for(int i = 1; i <list.length; i++)
      {
         int currentElement = list[i];
         int k;
         for(k = i -1; k >= 0 && list[k] > currentElement; k--)
         {
            list[k+1] = list[k];
         }
         list[k + 1] = currentElement;
      }
      return list;
   }
   
   /*8
   *This algorithm divides the list into 2 seperate parts sorts then and then merges
   * back together It takes in an int[] array
   */
   public static int[] InsertionSortM(int[] list)
   {
      int mid = 0;
      int length1 = 0;
      int length2 = 0;
      
      //Determines mid
      for(int count = 0; count < list.length; count++)
         mid = mid + list[count];
      mid = mid/list.length;
      
      //Determines length of List1 and list2
      for(int count = 0; count < list.length; count++)
      {
         if(list[count] <= mid)
            length1++; //Determines list1 length
         else
            length2++; //Determines list2 length
      }
      
      int[] list1 = new int[length1];
      int[] list2 = new int[length2];
      length1 = 0;
      length2 = 0;

      //Inserts the values into the Array
      for(int count = 0; count < list.length; count++)
      {
         if(list[count] <= mid)
         {
            list1[length1] = list[count];
            length1++;
         }
         else
         {
            list2[length2] = list[count];
            length2++;
         }
      }   
      
      list1 = InsertionSort(list1);
      list2 = InsertionSort(list2);
        
      //Merges the sorted lists together      
      int[] list3 = new int[list1.length + list2.length];
      System.arraycopy(list1, 0, list3, 0, list1.length);
      System.arraycopy(list2, 0, list3, list1.length, list2.length);
      
      System.out.println("The mid Value is: " + mid + "\n");
      
      System.out.print("List 1:\t");
      printArray(list1);
      
      System.out.print("List 2:\t");
      printArray(list2);
      
      System.out.print("Merged List:\t");
      printArray(list3);
      
      return list3;
   }
   
   public static void main(String[] args) 
   {
      ModSelSort myMain = new ModSelSort();
      //Recieves array size
      System.out.println("Enter the Array Size(n):\t");
      int n = myMain.readInt(); 
      int[] myArray = new int[n];
      
      //Fills array with randomly generated numbers between 1,10
      for(int count = 0; count < n; count++)
      {
         myArray[count] = myMain.generateNum(1,10);
         System.out.print(myArray[count]+ ", ");
      }  
      
      System.out.println("\n");
      int[] mySortedArray = new int[myArray.length];
      
      //Splits lsit into 2 smaller lists and sorts and then merges
      mySortedArray = InsertionSortM(myArray);
      
   }
}