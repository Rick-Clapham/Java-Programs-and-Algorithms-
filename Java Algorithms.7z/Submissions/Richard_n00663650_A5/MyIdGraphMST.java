/******************************************************
*Name: Rick Clapham
*Date: 12/3/2015
*StudentID: 821-490-125
*Program: CENG318
******************************************************/
import javax.swing.*;
import java.util.*;

public class MyIdGraphMST {
 
    //Initalize values
    public static ArrayList<Integer> myVertices;    
    public static ArrayList<Integer> myVisited;
    public static int[][] myEdges;
    public static int[][] myWeights;
    public static StringBuffer myStringBufferPath;
    public static StringBuffer myStringBufferOutput;  
   
    public static void main(String[] args) {
        
        initializeValues();
        
        int startVertex = Integer.parseInt(JOptionPane.showInputDialog(null,"Enter starting vertex of MST: " + myVertices));
        
        int totalWeight = 0;
        
        //counts every vertex has been visited
        for(int x = 0; x < myVertices.size(); x++) {
            int smallest = 999;      
            int v1 = 999 , v2 = 999;   
            
            if(x == 0)
                myVisited.add(startVertex);
            
            else {
                //check every visited vertices and weights
                for(int y = 0; y < myVisited.size(); y++) {
                    //check every path for every visited vertex
                    for(int z = 0; z < myEdges[myVertices.indexOf(myVisited.get(y))].length; z++) {
                        if(checkVisited(myEdges[myVertices.indexOf(myVisited.get(y))][z]) == false) {
                            //compare weights and store smallest
                            if(myWeights[myVertices.indexOf(myVisited.get(y))][z] < smallest) {        
                                smallest = myWeights[myVertices.indexOf(myVisited.get(y))][z];
                                v1 = myVisited.get(y);
                                v2 = myEdges[myVertices.indexOf(myVisited.get(y))][z];  
                            }    
                        }
                    }
                }
                myVisited.add(v2);                 //add to myVisited
                totalWeight += smallest;        //add weight to total
                myStringBufferPath.append("From vertex " + v1 + " to vertex " + v2 + "\n"); // build string to print
                myStringBufferOutput.append(smallest + " + ");                                // build string to print
            }
            
        }
        
        JOptionPane.showMessageDialog(null,"Sequence MST (starting from " + startVertex + ") : \n" + myStringBufferPath + "\n Total weight of MST: \n" + myStringBufferOutput + "= " + totalWeight);   
    }
    
    
    public static void initializeValues() {
     
        //initalize values
        myVertices = new ArrayList<>();
        myVertices.add(8);
        myVertices.add(2);
        myVertices.add(1);
        myVertices.add(4);
        myVertices.add(9); 
        myVertices.add(0); 
        myVertices.add(5);
        
        myEdges = new int[][] {{2,5},{8,0,1},{2,4},{1,9},{4,0},{9,2,5},{0,8}};
        myWeights = new int[][] {{5,1},{5,12,3},{3,7},{7,2},{2,6},{6,12,4},{4,1}};
        
        myVisited = new ArrayList<Integer>();     
        
        myStringBufferPath = new StringBuffer();
        myStringBufferOutput = new StringBuffer();
    }
    
    //check if vertex has been myVisited
    public static boolean checkVisited(int value) {
       return myVisited.contains(value);  
    }
}




