/**
* Name: Rick Clapham
* Student #: 821-490-125
* Student ID: n00663650
* Last Modified: 12/15/2015
* Section: N/A
* Question: Set E
*****/

import java.io.*;
import java.net.*;
import java.util.Enumeration;
import java.awt.*;
import javax.swing.*;
import javax.swing.JScrollPane;
import java.awt.event.ItemListener;
import java.awt.event.ItemEvent;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.*;
import javax.swing.SwingUtilities;
import javax.swing.filechooser.*;
import java.nio.file.*;
import java.util.concurrent.*;
import java.util.concurrent.locks.*;
import java.util.*;
import java.util.ArrayList;

public class Richard_821490125
{
   public int cancelledShelters = 0;
   public int numberOfBookedShelters = 0;
   
   public void setCancelledShelters(int i){cancelledShelters = i;}
   public int getCancelledShelters(){return cancelledShelters;}
   public int getNumberOfBookedShelters(){return numberOfBookedShelters;}
   
   public synchronized void cancelAShelter()
   {
      if(cancelledShelters < numberOfBookedShelters){
         int newCancelledShelters = cancelledShelters + 1;
         cancelledShelters = newCancelledShelters;
      }
      else{
         System.out.println("All Shelters are Booked");
      }
   }
   
   public static int readInt()
	{
		int i = 0;		//Initialize for return
		boolean failure = false;
		Scanner in = new Scanner(System.in);
		do
		{
			failure = false;	//Reinitialize for if
			if (in.hasNextInt())
         {
				i = in.nextInt(); //Good one
            if(i < 0)
            {
               failure = true;
				   System.out.print("Please enter a positive integer: ");
            }
         } 
			else
			{
				failure = true;
				String temp = in.next();	//Clear the buffer
				System.out.print("Please enter an integer: ");
			}
		}while(failure); 	
		return i;
	}
   
	public static void main(String [] args)
   {
		try 
      {
         Richard_821490125 myClass = new Richard_821490125();
         System.out.println("\n--------------------------------------------------");
         System.out.println("Enter The number of shelters please:");
         myClass.numberOfBookedShelters = readInt();
         System.out.println("\n--------------------------------------------------");
         System.out.println("The Number of Shelters is:\t" + myClass.numberOfBookedShelters);
			Shelter1 mySender = new Shelter1(myClass);
			Thread myThread1 = new Thread(mySender);
         myThread1.start();
			Shelter2 myReciever = new Shelter2(myClass);
			Thread myThread2 =new Thread(myReciever);
         myThread2.start();
		} 
      catch (Exception e) {System.out.println(e.getMessage());} 
	}
}

class Shelter1 implements Runnable
{
   private int shelterCanceled = 0;
   private int random = 0;
   private Richard_821490125 mySubClass;
	
	public Shelter1(){}//end constructor
   public Shelter1(Richard_821490125 test) {mySubClass = test;}
   
	public void run()
   {
		try
      {
      for(int count = 0;count < 10000; count++){
         random = (int)(Math. random() * 50 + 1);
		   if(random == 40)
         {
            if(mySubClass.getCancelledShelters() != mySubClass.getNumberOfBookedShelters()){
               shelterCanceled = shelterCanceled + 1;
            }
            mySubClass.cancelAShelter();
            System.out.println("This is Shelter 1 Amount of Cancelled Shelters is:\t" + mySubClass.getCancelledShelters());
            System.out.println("Shelter 1: The Amount of Shelters I have Cancelled is:\t" + shelterCanceled);
         }
      }
      }catch(Exception e){System.out.println(e.getMessage());}
	}
}

class Shelter2 implements Runnable
{
   private int shelterCanceled = 0;
   private int random = 0;
   private Richard_821490125 mySubClass;
	
	public Shelter2(){}//end constructor
   public Shelter2(Richard_821490125 test) {mySubClass = test;}
   
	public void run()
   {
		try
      {
      for(int count = 0;count < 10000; count++){
         random = (int)(Math. random() * 50 + 1);
		   if(random == 40)
         {
            if(mySubClass.getCancelledShelters() != mySubClass.getNumberOfBookedShelters()){
               shelterCanceled = shelterCanceled + 1;
            }
            mySubClass.cancelAShelter();
            System.out.println("This is Shelter 2 Amount of Cancelled Shelters is:\t" + mySubClass.getCancelledShelters());
            System.out.println("Shelter 2: The Amount of Shelters I have Cancelled is:\t" + shelterCanceled);
         }
      }
      }catch(Exception e){System.out.println(e.getMessage());}
	}
}